package com.mhl.routertester
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.max
import kotlin.math.min
class MainActivity : AppCompatActivity() {
    private var isTesting = false
    private var success = 0; private var failed = 0; private var maxSustained = 0
    private val scope = CoroutineScope(Dispatchers.Main + Job())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val ipInput = findViewById<TextInputEditText>(R.id.ipInput)
        val portInput = findViewById<TextInputEditText>(R.id.portInput)
        val slider = findViewById<Slider>(R.id.concurrentSlider)
        val label = findViewById<TextView>(R.id.concurrentLabel)
        val successText = findViewById<TextView>(R.id.successText)
        val failedText = findViewById<TextView>(R.id.failedText)
        val maxText = findViewById<TextView>(R.id.maxText)
        val startBtn = findViewById<MaterialButton>(R.id.startBtn)
        val logView = findViewById<TextView>(R.id.logView)
        fun log(msg: String){
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
            logView.text = "$time - $msg\n" + logView.text
        }
        slider.addOnChangeListener { _, value, _ -> label.text = "عدد الاتصالات: ${value.toInt()}" }
        suspend fun testOne(ip: String, port: Int): Boolean = withContext(Dispatchers.IO){
            try { val s = Socket(); s.connect(InetSocketAddress(ip, port), 3000); s.close(); true } catch (e: Exception){ false }
        }
        startBtn.setOnClickListener {
            if (isTesting){ isTesting = false; startBtn.text = "بدء الاختبار"; log("تم الإيقاف"); return@setOnClickListener }
            isTesting = true; success = 0; failed = 0; maxSustained = 0
            successText.text = "نجح: 0"; failedText.text = "فشل: 0"; maxText.text = "أقصى: 0"; logView.text = ""
            startBtn.text = "إيقاف"; val ip = ipInput.text.toString().ifBlank { "192.168.1.1" }; val port = portInput.text.toString().toIntOrNull() ?: 80; val total = slider.value.toInt()
            log("بدء على $ip:$port - هدف $total")
            scope.launch {
                var tested = 0; var batch = 10
                while (tested < total && isTesting){
                    val cur = min(batch, total - tested)
                    val jobs = (0 until cur).map { async { testOne(ip, port) } }
                    val res = jobs.awaitAll(); val f = res.count { !it }; val s = res.count { it }
                    success += s; failed += f; maxSustained = max(maxSustained, success)
                    withContext(Dispatchers.Main){ successText.text = "نجح: $success"; failedText.text = "فشل: $failed"; maxText.text = "أقصى: $maxSustained" }
                    if (f > cur * 0.4){ log("⚠️ انهيار عند $tested - فشل ${(f*100/cur)}%"); break }
                    tested += cur; batch = min(batch + 5, 50); if (tested % 50 == 0) log("تم $tested / $total"); delay(300)
                }
                log("انتهى - أقصى تحمل: $maxSustained"); isTesting = false; startBtn.text = "بدء الاختبار"
            }
        }
    }
}
